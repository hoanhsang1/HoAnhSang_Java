module TaomoiTV {
	exports TaomoiTV;
}